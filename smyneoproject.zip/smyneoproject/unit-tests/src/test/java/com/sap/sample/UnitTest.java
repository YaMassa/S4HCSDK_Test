package com.sap.sample;

import org.junit.Test;

import static org.junit.Assert.*;

public class UnitTest {
    @Test
    public void test() {
        assertTrue(true);
    }
}
